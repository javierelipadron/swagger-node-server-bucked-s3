module.exports = {
    ENV: process.env.NODE_ENV || 'development',
    AWS: {
        ACCESSKEY: "AKIAJYK6HYJXM22OQ3OA",
        SECRETKEY: "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",
        REGION : "us-east-1"
    }
}
